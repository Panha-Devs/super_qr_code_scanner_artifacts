
#include "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/opencv/modules/core/src/precomp.hpp"
#include "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/opencv/modules/core/src/convert.simd.hpp"
