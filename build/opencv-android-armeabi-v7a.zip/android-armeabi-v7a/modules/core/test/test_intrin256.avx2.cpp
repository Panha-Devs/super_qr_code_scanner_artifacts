
#include "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/opencv/modules/core/test/test_precomp.hpp"
#include "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/opencv/modules/core/test/test_intrin256.simd.hpp"
