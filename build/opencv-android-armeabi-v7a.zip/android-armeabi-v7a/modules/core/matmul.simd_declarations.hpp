#define CV_CPU_SIMD_FILENAME "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/opencv/modules/core/src/matmul.simd.hpp"
#define CV_CPU_DISPATCH_MODES_ALL BASELINE

#undef CV_CPU_SIMD_FILENAME
