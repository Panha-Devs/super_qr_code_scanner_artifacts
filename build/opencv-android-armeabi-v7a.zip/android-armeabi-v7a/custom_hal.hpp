#ifndef _CUSTOM_HAL_INCLUDED_
#define _CUSTOM_HAL_INCLUDED_


#include "carotene/tegra_hal.hpp"

#endif
