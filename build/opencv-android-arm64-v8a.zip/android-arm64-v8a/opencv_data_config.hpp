
#define OPENCV_INSTALL_PREFIX "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/custom_build/build/android-arm64-v8a/install"

#define OPENCV_DATA_INSTALL_PATH "sdk/etc"

#define OPENCV_BUILD_DIR "/Users/vtech/CodeWorkspaces/C++/qr_code_scanner/custom_build/build/android-arm64-v8a"

#define OPENCV_DATA_BUILD_DIR_SEARCH_PATHS \
    "../../../opencv/"

#define OPENCV_INSTALL_DATA_DIR_RELATIVE "../../../etc"
